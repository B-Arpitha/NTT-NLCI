create database db1;
use db1;
create table employee (Employee_Id integer AUTO_INCREMENT, Employee_Name varchar(10) , Employee_Address varchar(20),
 Date_of_Joining date, Experience integer, Date_of_Birth date,primary key(Employee_Id));
insert into employee(Employee_Name, Employee_Address, Date_of_Joining, Experience, Date_of_Birth) values 
( 'arpitha','Blore','2019-07-04','1','1998-01-21');

