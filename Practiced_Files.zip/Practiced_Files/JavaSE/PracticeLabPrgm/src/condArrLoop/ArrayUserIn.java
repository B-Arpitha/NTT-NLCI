package condArrLoop;

import java.util.Scanner;

public class ArrayUserIn {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		  int[] arr = new int[5]; // declaring array and allocating memory for 5 integers. 

		  for(int i = 0 ; i < arr.length; i++)
		  {
			  Scanner s = new Scanner(System.in);
			  System.out.println("Enter the "+ i +" element of the array");
			  arr[i] = s.nextInt();
		  }
	      for (int i = 0; i < arr.length; i++) // accessing the elements of the specified array 
	      {
	          System.out.println("Element at index " + i +" is "+ arr[i]);
	      }

	}

}
