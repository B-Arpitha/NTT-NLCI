package condArrLoop;

public class Loops {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("For Loop");
	    for(int i = 1; i <= 5; i++) //Code of Java for loop  
	    {  
	        System.out.println(i); 
	    }
//-----------------------------------------------------------------------------
// 	Nested For Loop
	 
	    System.out.println("Nested For Loop");
	    for(int i = 1 ;i <= 3 ; i++)  //loop of i  
	    {  
	    	for(int j = 1 ; j <= 3 ; j++)//loop of j  
	    	{  
	            System.out.println(i +" "+ j);  
	    	}       //end of i  
	    }          //end of j  
//-----------------------------------------------------------------------------
//	For-each Loop	  
	     
	    System.out.println("For Each Loop");
	    int arr[] = { 4 , 9 , 16 , 25 };  //Declaring an array 
	     
	    for(int i : arr) //Printing array using for-each loop 
	    {  
	        System.out.println(i);  
	    } 
//-----------------------------------------------------------------------------
//		While Loop	
	    
	    System.out.println("While Loop");
	    int i = 1;  
	    while(i <= 5)
	    {  
	        System.out.println(i);  //checks condition first if true enters the loop
	    	i++;  
	    }
//-----------------------------------------------------------------------------
//		Do- While Loop	
	    
	    System.out.println("Do-While Loop");
	    i = 1;
	    do
	    {  
	        System.out.println(i);   // this body is excecuted once before checking condition
	        i++;  
	    } while( i <= 5 ); //if condition true then loop continues

	}

}
