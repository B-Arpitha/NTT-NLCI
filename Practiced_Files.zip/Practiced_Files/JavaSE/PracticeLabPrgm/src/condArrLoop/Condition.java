package condArrLoop;

public class Condition {

	public static void main(String[] args) {
		
		int i = 6;
//if Statements
		System.out.println("if condition");
			if (i > 5) 
				System.out.println("i is greater than 5"); // This stmnt will be executed if cond is true
				System.out.println("outside of if");//This stmnt is executed irrespective of cond  
//-------------------------------------------------------------------------------------
//if-else Statements 
				System.out.println("if-else condition");
            if (i < 5) 
                System.out.println("i is smaller than 5"); //executed when if condition is true
            else if(i == 5)
            	System.out.println("i is equal to 5");// executed when else if condition is true
            else            
                System.out.println("i is greater than 5"); //executed if above conditions are false
//---------------------------------------------------------------------------------------
//switch statements
            System.out.println("switch condition");
            switch (i) 
            { 
            case 0: 	
                System.out.println("i is zero"); //executed if i = 0
                break; 
            case 1: 
                System.out.println("i is one"); //executed if i = 1
                break; 
            case 2: 
                System.out.println("i is two"); //executed if i = 2
                break; 
            default: 
                System.out.println("i is greater than 2"); //executed if i > 2
//--------------------------------------------------------------------------------------------
//nested if statements
                System.out.println("nested if condition");
                if (i < 10) 
                {  // Nested - if statement  
                    if (i < 5) 
                        System.out.println("i is smaller than 5"); //executed if i < 5
                    else if (i > 5) 
                        System.out.println("i is greater than 5"); //executed if i > 5
                    
                    else 
                    	System.out.println("i is equal to 5");//executed if i = 5
                }
                else
                     System.out.println("i is greater than 10"); //executed if i = 10
                } 
                
            
	}

}
