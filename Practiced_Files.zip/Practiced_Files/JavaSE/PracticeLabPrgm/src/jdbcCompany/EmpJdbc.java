package jdbcCompany;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class EmpJdbc 
{
	
	int createEmp(EmpPojo e) throws Exception 
	{
		
		
		
		Connection con = null;
		Statement stmt = null;
		
		try 
		{
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/db1","root","1234");
			stmt= con.createStatement();
		} 
		catch (ClassNotFoundException ex) 
		{
			
			ex.printStackTrace();
		}

		
	     
	     
		PreparedStatement pt = con.prepareStatement("insert into employee"
				+ "(Employee_Name, Employee_Address, Date_of_Joining, Experience, Date_of_Birth) values \r\n" + 
				"( ?,?,?,?,?)");
		
		pt.setString(1,e.getEmployee_Name());
		pt.setString(2,e.getEmployee_Address());
		pt.setString(3,e.getDate_of_Joining());
		pt.setInt(4,e.getExperience());
		pt.setString(5,e.getDate_of_Birth());
		int r = pt.executeUpdate();
		stmt.close();
	    con.close();
		return r;
		
	}
	
	void readEmp() throws Exception 
	{
		Connection con = null;
		Statement stmt = null;
		
		try 
		{
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/db1","root","1234");
			stmt= con.createStatement();
		} 
		catch (ClassNotFoundException e) 
		{
			
			e.printStackTrace();
		}

		
		ResultSet rs= stmt.executeQuery("select * from employee ");	
		while(rs.next()) {
		
	    System.out.println("Employee_Id : "+rs.getInt("Employee_Id")+
	    		"\nEmployee_Name : "+rs.getString("Employee_Name")+
	    		"\nEmployee_Address : "+rs.getString("Employee_Address")+
	    		"\nDate_of_Joining : "+rs.getString("Date_of_Joining")+
	    		"\nExperience : "+rs.getInt("Experience")+
	    		"\nDate_of_Birth : "+rs.getString("Date_of_Birth")
	    		);
	    System.out.println("-------------------------------------------------------");
		}
		
		
		stmt.close();
	    con.close();
	
	}
	
	int updateEmp(EmpPojo x) throws Exception 
	{
		Connection con = null;
		Statement stmt = null;
		
		try 
		{
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/db1","root","1234");
			stmt= con.createStatement();
		} 
		catch (ClassNotFoundException e) 
		{
			
			e.printStackTrace();
		}

		PreparedStatement pt = con.prepareStatement(" update employee SET Employee_Name = ?, Employee_Address = ?, Date_of_Joining=?, Experience =?,Date_of_Birth=?\r\n" + 
				" where Employee_Id = ?");
		pt.setInt(6, x.getEmployee_Id());
		pt.setString(1,x.getEmployee_Name());
		pt.setString(2,x.getEmployee_Address());
		pt.setString(3,x.getDate_of_Joining());
		pt.setInt(4,x.getExperience());
		pt.setString(5,x.getDate_of_Birth());
		
		
		int r = pt.executeUpdate();
		
		stmt.close();
	    con.close();
		return r;
		
	}
	
	int deleteEmp(EmpPojo x) throws Exception 
	{
		Connection con = null;
		Statement stmt = null;
		
		try 
		{
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/db1","root","1234");
			stmt= con.createStatement();
		} 
		catch (ClassNotFoundException e) 
		{
			
			e.printStackTrace();
		}

		PreparedStatement pt = con.prepareStatement("delete from employee where Employee_Id = ?");
		pt.setInt(1, x.getEmployee_Id());
	
		int r = pt.executeUpdate();
		
		stmt.close();
	    con.close();
		return r;
		
	}

}
