package jdbcCompany;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.util.Scanner;

public class EmpMain {

	public static void main(String[] args) throws Exception 
	{
		
		EmpJdbc empjdbc = new EmpJdbc();
		EmpPojo e = new EmpPojo();
		int ch=0;
		
		while(ch==0)
		{
		System.out.println("select the option");
		System.out.println("1 -> Create an Employee");
		System.out.println("2 -> Read Employee details");
		System.out.println("3 -> Update Employee details");
		System.out.println("4 -> Delete Employee");
		
		Scanner sc=new Scanner(System.in);	
		int option = sc.nextInt();
		
		switch(option)
		{
		
		case 1 :{
			System.out.println("Enter Emp_Name");
		     e.setEmployee_Name(sc.next());
		     System.out.println("Enter Emp_Add");
		     e.setEmployee_Address(sc.next());
		     System.out.println("Enter Date_of_joining");
		     e.setDate_of_Joining(sc.next());
		     System.out.println("Enter Experience");
		     e.setExperience(sc.nextInt());
		     System.out.println("Enter Date_of_Birth");
		     e.setDate_of_Birth(sc.next());
			     int val = empjdbc.createEmp(e);
			     if(val==0)
			    	 System.out.println("Employee not Created");
			     else
			    	 System.out.println("Employee Created");
			     break;
		        }
		
		case 2:{
		         // System.out.println("Enter Emp_Id");
		        //  e.setEmployee_Id(sc.nextInt());
		          empjdbc.readEmp();
		          break;
		       }
		
		case 3:{
			       System.out.println("Enter Emp_Id to update its details");
			       e.setEmployee_Id(sc.nextInt());
			       System.out.println("Enter Emp_Name");
		           e.setEmployee_Name(sc.next());
		           System.out.println("Enter Emp_Add");
		           e.setEmployee_Address(sc.next());
		           System.out.println("Enter Date_of_joining");
		           e.setDate_of_Joining(sc.next());
		           System.out.println("Enter Experience");
		           e.setExperience(sc.nextInt());
		           System.out.println("Enter Date_of_Birth");
		           e.setDate_of_Birth(sc.next());
		           int val = empjdbc.updateEmp(e);
		           if(val==0)
		    	    System.out.println("Employee details not Updated");
		           else
		    	    System.out.println("Employee details Updated");
		           break;
			      			
		       }
		case 4:{
		       System.out.println("Enter Emp_Id to Delete employee");
		       e.setEmployee_Id(sc.nextInt());
		       
	           int val = empjdbc.deleteEmp(e);
	           if(val==0)
	    	    System.out.println("Employee not Deleted");
	           else
	    	    System.out.println("Employee Deleted");
	           break;
		      			
	       }
		
		} 
		
		System.out.println("Press 0 to continue");
		ch = sc.nextInt();
		}

	}

}
