package javaBasics;

public class VarArgs 
{
	 
    static void disp(int ...a) // A method that takes variable number of integer arguments.
    { 
        System.out.println("Number of arguments received: " + a.length);
        for (int i: a)  // using for each loop to display contents of a 
        {
        	System.out.print(i + " "); 
        }
        System.out.println(); 
    } 
  
    public static void main(String args[]) 
    { 
        disp(100);         // one parameter 
        disp(1, 2, 3, 4);  // four parameters 
        disp();            // no parameter 
        disp(10,9,8,7,6,5,4,3,2,1); // ten parameters 
        disp(5648,8541);  // two parameters 
    } 

}
