package javaBasics;

public final class FinalEx //class is final therefore this class cannot be inherited
{
	final static int a = 10;  //final variable value cannot be changed
	
	final static void func() // this method cannot be overridden if inherited
	{
		System.out.println("Inside final func method");
	}

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		System.out.println(a); //prints final var
		//  a = 30; this is not possible bcz final var value cannot be altered
		func(); //calling final method
		
	}

}
