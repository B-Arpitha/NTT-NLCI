package javaBasics;

public class Constructors {

	Constructors()
	{
		System.out.println("Default constructor is called");  //creating a default constructor 
	}
	
	int id ;
	int age;
	String name;
	
    Constructors(int id,String name)  //creating a parameterized constructor  
    {  
    	 this.id = id;
    	 this.name = name;
    	 System.out.print("id:"+id +" name:"+ name);
    } 
    Constructors(int id,String name,int age)
    {  
     
      this(id, name); //calling other constructor within a constructor
      this.age = age;
      System.out.println(" age: "+age);
    }
	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Constructors c = new Constructors();  //calling a default constructor  
		Constructors c1 = new Constructors(101,"Arpitha"); //calling a parameterized constructor
		 System.out.println();
		Constructors c2 = new Constructors(102,"Dhruthi",12);
	}

	

}
