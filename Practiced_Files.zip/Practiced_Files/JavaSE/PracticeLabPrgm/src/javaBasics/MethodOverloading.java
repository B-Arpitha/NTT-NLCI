package javaBasics;

public class MethodOverloading {
	
	 void sum(int a,long b)
	 {
		 System.out.println(a+b); 
	 }
	 void sum(int a,float b)
	 {
		 System.out.println(a+b); 
	 }
	 void sum(int a,int b,int c)
	 {
		 System.out.println(a+b+c); 
	 }
	  
	 
	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		
		  MethodOverloading obj=new MethodOverloading();  
		  obj.sum(20,20);  // void sum(int a,long b) is called and second parameter will be promoted to long  
		  obj.sum(20,20,20); //void sum(int a,int b,int c) is called
		  obj.sum(60,20.50f); //void sum(int a,float b) is called 
		  obj.sum(12,26,66); //void sum(int a,int b,int c) is called
		  
		  
		  
	}

}
