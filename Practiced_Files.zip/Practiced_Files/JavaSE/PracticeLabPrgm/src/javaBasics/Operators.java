package javaBasics;

public class Operators {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		  int  a = 6, b = 12;
		  String out = ( a==b ? "Yes, a is equal to b":"No, a is not-equal to b" ); // Contional Operator
		  System.out.println(out);
		  
		  System.out.println(a++);//post increment
		  System.out.println(++a);//pre increment
		  System.out.println(b--);//post decrement
		  System.out.println(--b);//pre decrement
		  
		  int x = 10, y = 15;
		  
		  if( x == y)  // equality operator
		  System.out.println( "x is equal to y" );  
		  if( x != y)  // not operator
			  System.out.println( "x is not equal to y");          
		  if( x > y ) 
			  System.out.println(" x is greater than y");
		  if(x < y )   //lesser than operator       
			  System.out.println("x is less than y");
		  if(x >= y)   //greater than or equal to operator
			  System.out.println("x is greater than or equal to y");
		  if(x <= y)     //lesser than or equal to operator   
			  System.out.println(" x is less than or equal to y");
		  
		  if((x == 10) && (y == 15))  //AND operator
	            System.out.println("x is 10 AND y is 15");
	        if((x == 15) || (y == 15))  //Or operator
	            System.out.println("x is 15 OR y is 15");
		  
		  

	}

}
