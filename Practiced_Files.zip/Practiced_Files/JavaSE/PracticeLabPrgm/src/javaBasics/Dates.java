package javaBasics;

import java.util.Calendar;
import java.util.Date;

public class Dates {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Date d1 = new Date(2020, 00, 21); 
        Date d2 = new Date();   // Current date
        
        System.out.println(d1.after(d2)); //prints boolean exp: true 
        System.out.println(d1.before(d2));  //prints boolean exp: false
        System.out.println(d1.compareTo(d2)); //1 is returned because d2 is after d1
        
        System.out.println(d2.getDay()); //prints day
        System.out.println(d2.getMonth());  //prints Month
        
        System.out.println(d2.getTime());  //prints time
        
        System.out.println("Before Setting: "+d1); //prints time before setting
        d1.setTime(204587433443L);
        System.out.println("After Setting: "+d1); //prints time after setting
        
     
        Calendar calendar = Calendar.getInstance(); // creating Calendar object 
          
        System.out.println("Current Calendar's Year: " + calendar.get(Calendar.YEAR)); 
        System.out.println("Current Calendar's Day: " + calendar.get(Calendar.DATE)); 
        System.out.println("Current MINUTE: " + calendar.get(Calendar.MINUTE)); 
        System.out.println("Current SECOND: " + calendar.get(Calendar.SECOND)); 
        

	}

}
