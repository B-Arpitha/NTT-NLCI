package javaBasics;

import java.util.ArrayList; 

class LambdaExp 
{ 
    public static void main(String args[]) 
    { 
       
        ArrayList<Integer> arrL = new ArrayList<Integer>();  // Creating an ArrayList with elements 
        arrL.add(1); 
        arrL.add(2); 
        arrL.add(3); 
        arrL.add(4); 
        
        System.out.println("All the elements in array");
        arrL.forEach(n -> System.out.println(n)); // Using lambda expression to print all elements 
        System.out.println("----------------------------------------");
        
        System.out.println("Even elements in array");
        arrL.forEach(n -> { if (n%2 == 0) System.out.println(n); }); // Using lambda expression to print even elements 
    } 
} 

