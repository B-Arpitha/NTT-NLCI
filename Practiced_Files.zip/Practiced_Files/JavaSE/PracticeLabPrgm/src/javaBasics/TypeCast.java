package javaBasics;

public class TypeCast {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	int i = 100;     
    long l = i;  // automatic type conversion 
    float f = l;  // automatic type conversion 
    
    System.out.println("Int value "+i); 
    System.out.println("Long value "+l); 
    System.out.println("Float value "+f); 
    
    char ch = (char) i; //explicit type casting
    System.out.println("Char Value "+ch);
    
    double d = 100.04;   
    l = (long)d;  //explicit type casting  
    i = (int)l;   //explicit type casting
    
    System.out.println("Double value "+d); 
    System.out.println("Long value "+l);  
    System.out.println("Int value "+i);
    
    
	}
}
