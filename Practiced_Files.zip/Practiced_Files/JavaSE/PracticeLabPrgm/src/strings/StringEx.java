package strings;

public class StringEx {

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		
		String s1 = "java";//creating string by java string literal  
		System.out.println(s1);  
		
		char ch[] = {'s','t','r','i','n','g','s'};  
		String s2 = new String(ch);//converting char array to string 
		System.out.println(s2); 
		
		
		

	}

}

