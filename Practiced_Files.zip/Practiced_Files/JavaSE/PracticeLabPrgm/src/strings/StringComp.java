package strings;

public class StringComp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 String s = "Sachin"; 
		   
		 s.concat(" Tendulkar");  
		 System.out.println(s); //s value doesn't change since s is immutable 
		 
		 s = s.concat(" Tendulkar");  
		 System.out.println(s); // explicitly assign it to the reference variable
		  
		 String s1 = "Sachin";  
		 String s2 = new String("Sachin");  
		 
		 System.out.println(s == s1);  //true (because both refer to same instance)  
		 System.out.println(s == s2);  //false(because s2 refers to instance created in non-pool)
		 
		 System.out.println(s.equals(s1)); //true because values are compared
		 System.out.println(s.equals(s2)); //true because values are compared  
		 
		 String s3 = "SACHIN";
		 System.out.println(s.equals(s3)); //false because case is also considered
		 System.out.println(s.equalsIgnoreCase(s3)); //true because case is Ignored
		 
		 String s4 = "Ratan"; 
		 System.out.println(s.compareTo(s1));  //0  
		 System.out.println(s.compareTo(s4));  //1(because s > s4)
		 System.out.println(s4.compareTo(s));  //-1(because s4 < s ) 
		 
		 

	}

}
