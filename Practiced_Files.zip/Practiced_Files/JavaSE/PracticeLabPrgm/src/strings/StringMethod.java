package strings;

public class StringMethod {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String name = "Sachin Tendulkar";  
		char ch = name.charAt(4);//returns the char value at the 4th index if index value of out of range then exception is thrown
		System.out.println(ch); 
		
		System.out.println(name.contains("in"));  //returns true 
		System.out.println(name.contains("rahul"));  // returns false
		
		System.out.println(name.endsWith("r"));  //true
		System.out.println(name.endsWith("Tendulkar")); //true
		
		System.out.println(String.format("name is %s",name)); //prints name
		  
		System.out.println(name.indexOf("Tend")); // returns index of starting char in "Tend"
		
		String joinString=String.join(" ","Welcome","to","eclipse");  
		System.out.println(joinString);
		
		System.out.println("string length is: "+name.length());  //16 is string length
		
		String s1="bangalore";  
		System.out.println(s1.replace('b','m'));// mangalore is printed
		
		System.out.println(name.substring(4,7));// prints 'in'
		
		s1="  hello  ";  
		System.out.println(s1+"world"); //without trim()  
		System.out.println(s1.trim()+"world"); //with trim()	
		
		s1="hello";  
		char[] ch1 = s1.toCharArray();  //Converts string to a new char array.
		for(int i=0;i<ch1.length;i++)
		{  
		System.out.print(ch1[i]);  
		}

	}

}
