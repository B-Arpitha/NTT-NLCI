package Encapsulation;

class Dog
{
	private String name , breed;
	private int cost;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getBreed() {
		return breed;
	}
	public void setBreed(String breed) {
		this.breed = breed;
	}
	public int getCost() {
		return cost;
	}
	public void setCost(int cost) {
		this.cost = cost;
	}
	
	public Dog(String name, int cost, String breed) {
		super();
		this.name = name;
		this.breed = breed;
		this.cost = cost;
	}	
}

public class pojo1 {

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		
		Dog d = new Dog("Tommy",200,"pug");
		System.out.println(d.getName());
		System.out.println(d.getBreed());
		System.out.println(d.getCost());
		
	}

}
