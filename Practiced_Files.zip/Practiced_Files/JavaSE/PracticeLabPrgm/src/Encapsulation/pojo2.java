package Encapsulation;

import java.util.Scanner;

class Student 
{
	private int st_id,st_age;
	private String st_name,st_adress;
	public int getSt_id() {
		return st_id;
	}
	public void setSt_id(int st_id) {
		this.st_id = st_id;
	}
	public int getSt_age() {
		return st_age;
	}
	public void setSt_age(int st_age) {
		this.st_age = st_age;
	}
	public String getSt_name() {
		return st_name;
	}
	public void setSt_name(String st_name) {
		this.st_name = st_name;
	}
	public String getSt_adress() {
		return st_adress;
	}
	public void setSt_adress(String st_adress) {
		this.st_adress = st_adress;
	}
	public Student(int st_id, int st_age, String st_name, String st_adress) {
		super();
		this.st_id = st_id;
		this.st_age = st_age;
		this.st_name = st_name;
		this.st_adress = st_adress;
	}
	public Student() {
		super();
	}
	
}

public class pojo2 {

	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		// TODO Auto-generated method stub
		Student st = new Student();
		System.out.println("Enter student name");
		st.setSt_name(sc.next());
		System.out.println("Enter student id");
		st.setSt_id(sc.nextInt());
		System.out.println("Enter student age");
		st.setSt_age(sc.nextInt());
		System.out.println("Enter student address");
		st.setSt_adress(sc.next());
		
		System.out.println("Student Name: "+st.getSt_name()+"\nStudent Id: "+st.getSt_id()+"\nStudent Age: "+st.getSt_age()+"\nStudent Address: "+st.getSt_adress());
		
		

	}

}
