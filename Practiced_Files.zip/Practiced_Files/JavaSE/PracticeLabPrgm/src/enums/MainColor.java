package enums;

public class MainColor {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		 	EnumColor c1 = EnumColor.RED; 
	        System.out.println(c1); 
	        c1.colorInfo(c1);

	}

}
