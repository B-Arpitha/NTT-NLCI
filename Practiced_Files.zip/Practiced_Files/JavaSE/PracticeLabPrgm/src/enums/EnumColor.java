package enums;

public enum EnumColor {
	
	    RED, GREEN, BLUE; 
	    
	    private EnumColor()    // enum constructor called separately for each colors without calling
	    { 
	        System.out.println("Constructor called for : " + this.toString()); 
	    } 
	  
	    public void colorInfo(EnumColor c1) 
	    { 
	        System.out.println("Primary Color: "+c1); 
	    } 
	

}
