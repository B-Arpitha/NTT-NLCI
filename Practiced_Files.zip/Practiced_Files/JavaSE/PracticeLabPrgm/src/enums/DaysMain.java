package enums;

public class DaysMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		EnumDays arr[] = EnumDays.values(); 
		
		 for(EnumDays day : arr)
		 {
			 System.out.println(day);
		 }

	}

}
