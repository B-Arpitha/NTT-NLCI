package polymorphism;


class Plane
{
	void takeoff()
	{
		System.out.println("Plane is taking off");
	}
	void fly()
	{
		System.out.println("Plane is flying");
	}
	void land()
	{
		System.out.println("Plane is landing");
	}		
}

class PassengerPlane extends Plane //takeoff() Land() methods are inherited as it is
{
	void fly()  // Overridden Method
	{
		System.out.println("Passenger Plane is flying");
	}
}
class CargoPlane extends Plane //takeoff() Land() methods are inherited as it is
{
	void fly()  // Overridden Method
	{
		System.out.println("Cargo Plane is flying");
	}
}
class FighterPlane extends Plane //takeoff() Land() methods are inherited as it is
{
	void fly()  // Overridden Method
	{
		System.out.println("Fighter Plane is flying");
	}
} 

class Airport // Application class
{
	void permit(Plane ref)
	{
		ref.takeoff();
		ref.fly();
		ref.land();
	}
}

public class Example1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		PassengerPlane pp = new PassengerPlane();
		CargoPlane cp = new CargoPlane();
		FighterPlane fp = new FighterPlane();
		
		Airport a = new Airport();
		a.permit(pp); //passing child class reference to parent class
		System.out.println("--------------------------------------------------------");
		a.permit(cp);
		System.out.println("--------------------------------------------------------");
		a.permit(fp);
		
	}

}
