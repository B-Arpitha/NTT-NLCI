package generics;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Map;
import java.util.Set;

public class Collections 
{	
		public static void main(String args[])
		{  
			ArrayList<String> list=new ArrayList<String>();//Creating arraylist  
			LinkedList<String> al=new LinkedList<String>();  
			HashSet<String> set=new HashSet<String>();  
			Map map = new HashMap();
			
			list.add("a");//Adding object in arraylist  
			list.add("b");  
			list.add("c");  
			list.add("d"); 
			
			al.add("x");
			al.add("y");  
			al.add("z");  
			al.add("zz"); 
			
			set.add("l");
			set.add("m");  
			set.add("n");  
			set.add("o"); 
			
			map.put(1,"a");  
		    map.put(5,"b");  
		    map.put(2,"c");  
		    map.put(6,"d");  
		
			Iterator itr=list.iterator();  
			while(itr.hasNext())
			{  
				System.out.println(itr.next());  
			}  
			
			itr=al.iterator();  
			while(itr.hasNext())
			{  
				System.out.println(itr.next());
			} 
			
			Iterator<String> itr1=set.iterator();  
			while(itr1.hasNext())
			{  
			System.out.println(itr1.next());  
			}  
			 Set set1=map.entrySet();//Converting to Set so that we can traverse  
			 Iterator itr2=set1.iterator();  
			    while(itr2.hasNext())
			    {  
			        //Converting to Map.Entry so that we can get key and value separately  
			        Map.Entry entry=(Map.Entry)itr2.next();  
			        System.out.println(entry.getKey()+" "+entry.getValue());  
			    }  
		}  
}
