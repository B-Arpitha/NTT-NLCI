package generics;

public class GenericClass<T> {
   private T t;

   public void equ(T t) {
      this.t = t;
   }

   public T get() {
      return t;
   }

   public static void main(String[] args) {
      GenericClass<Integer> number = new GenericClass<Integer>();
      GenericClass<String> char1 = new GenericClass<String>();
    
      number.equ(new Integer(10));
      char1.equ(new String("Hello World"));

      System.out.println("Integer Value : "+ number.get());
      System.out.println("String Value : "+ char1.get());
   }
}
