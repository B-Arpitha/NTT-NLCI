package junit;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class Jtest {

	@Test
	  public void testFindMax()
	{  
		assertEquals(4,Test1.findMax(new int[]{1,3,4,2}));  
        assertEquals(-1,Test1.findMax(new int[]{-12,-1,-3,-4,-2}));  
    } 

}
