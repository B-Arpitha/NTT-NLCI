package interfaces;

import java.util.Scanner;

interface Calculator
{
	void add(int a , int b);
	void sub(int a , int b);
	void mul(int a , int b);
	public default void div(int a , int b)
	{
		System.out.println("Division Res: "+ (a/b));
	}
}

class MyCalc1 implements Calculator
{
	public void add(int a , int b)
	{
		System.out.println("Addition Res: "+ (a+b));
	}
	public void sub(int a , int b)
	{
		System.out.println("Subtraction Res: "+ (a-b));
	}
	public void mul(int a , int b)
	{
		System.out.println("Multiplication Res: "+ (a*b));
	}
}


public class Calculation 
{
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		MyCalc1 c1 = new MyCalc1();
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter value of a");
		int a = sc.nextInt();
		System.out.println("Enter the value of b and b should not be equal to zero ");
		int b = sc.nextInt();
		
		c1.add(a, b);
		System.out.println("------------------------------------------------------------------");
		c1.sub(a, b);
		System.out.println("------------------------------------------------------------------");
		c1.mul(a, b);
		System.out.println("------------------------------------------------------------------");
		c1.div(a, b);
		
	}

}
