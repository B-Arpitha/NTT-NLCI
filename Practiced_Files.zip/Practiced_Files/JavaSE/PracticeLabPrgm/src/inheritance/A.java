package inheritance;
  
class Demo1 
{ 
    int a,b;
    Demo1()
    {
    	a = 10;
    	b = 20;   	
    }
    
    Demo1(int m , int n)
    {
    	a = m;
    	b = n;
    }
} 
  
class Demo2 extends Demo1 
{ 
	int x,y;
    Demo2()
    {
    	super(1,2);
    	x = 10;
    	y = 20;   	
    }
    
    Demo2(int p , int q)
    {
    	x = p;
    	y = q;
    }
    public void disp() 
    { 
        System.out.println("a: "+a+" "+"b: "+b); 
        System.out.println("x: "+x+" "+"y: "+y);
    } 
} 
  

public class A
{ 
    public static void main(String[] args) 
    { 
       Demo2 d = new Demo2();
       d.disp();
       
       Demo2 d1 = new Demo2(11,22);
       d1.disp();     
    } 
}
