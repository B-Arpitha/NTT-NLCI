package inheritance;


		class Plane
		{
			void takeoff()
			{
				System.out.println("Plane is taking off");
			}
			void fly()
			{
				System.out.println("Plane is flying");
			}
			void land()
			{
				System.out.println("Plane is landing");
			}		
		}
		
		class PassengerPlane extends Plane //takeoff() Land() methods are inherited as it is
		{
			void fly()  // Overridden Method
			{
				System.out.println("Passenger Plane is flying");
			}
			void carryPassenger()  //Specialized Methods
			{
				System.out.println("Passenger plane carry passenger");
			}
		}
		class CargoPlane extends Plane //takeoff() Land() methods are inherited as it is
		{
			void fly()  // Overridden Method
			{
				System.out.println("Cargo Plane is flying");
			}
			void carryGoods()  //Specialized Methods
			{
				System.out.println("Cargo plane carry Goods");
			}
		}
		class FighterPlane extends Plane //takeoff() Land() methods are inherited as it is
		{
			void fly()  // Overridden Method
			{
				System.out.println("Fighter Plane is flying");
			}
			void carryWeapons()  //Specialized Methods
			{
				System.out.println("Fighter plane carry Weapons");
			}
		}
		
		public class MethodsInh {

			public static void main(String[] args) {
				// TODO Auto-generated method stub
				
				PassengerPlane pp = new PassengerPlane();
				CargoPlane cp = new CargoPlane();
				FighterPlane fp = new FighterPlane();
				
				pp.takeoff();
				pp.fly();
				pp.carryPassenger();
				pp.land();
				System.out.println("------------------------------------------------------------------");
				
				cp.takeoff();
				cp.fly();
				cp.carryGoods();
				cp.land();
				System.out.println("------------------------------------------------------------------");
				
				fp.takeoff();
				fp.fly();
				fp.carryWeapons();
				fp.land();
				System.out.println("------------------------------------------------------------------");
				
			}

}
