package multiThreading;

public class Deadlock 
{  
	  public static void main(String[] args) {  
		  
	    final String resource1 = "arpitha";  
	    
	    Thread t = new Thread() 
	    {  
	      public void run() 
	      {  
	          synchronized (resource1) 
	          {  
	           System.out.println("Thread 1: locked resource 1");  
	           try 
	           {
	        	   Thread.sleep(100);
	           }
	        	   
	           catch (Exception e)
	           {
	        	   System.out.println(e);
	           }  	           
	         }  
	      }  
	    };  

	    t.start();  
	    
	}  
}