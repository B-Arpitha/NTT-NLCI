package exceptions;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;

public class BuiltInExp {

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		
		
		try 
		{ 
            int a = 30, b = 0; 
            int c = a/b;           // cannot divide by zero , ArithmeticException
            System.out.println ("Result = " + c); 
            
            String s = null;         //null value , NullPointerException
            System.out.println(s.charAt(0));
            
            s = "This is like chipping ";          // length is 22 
            char ch = s.charAt(24);               // accessing 25th element , StringIndexOutOfBoundsException
            System.out.println(ch);
            
            File file = new File("E://file.txt");   // Following file does not exist 
            FileReader fr = new FileReader(file); 
            
            int num = Integer.parseInt ("abcd") ; // "abcd" is not a number , NumberFormatException
            
            int a1[] = new int[5]; 
            a1[6] = 9; // accessing 7th element in an array of  size 5 
            
        } 
		
		
        
        catch(ArithmeticException e) 
		{ 
            System.out.println ("Can't divide a number by 0"); 
        } 
		catch(NullPointerException e) 
		{ 
            System.out.println("NullPointerException.."); 
        } 
		catch(StringIndexOutOfBoundsException e) 
		{ 
            System.out.println("StringIndexOutOfBoundsException"); 
        } 
		catch (FileNotFoundException e) 
		{ 
	           System.out.println("File does not exist"); 
	    } 
		catch (NumberFormatException e) 
		{ 
            System.out.println("Number format exception"); 
        } 
		catch (ArrayIndexOutOfBoundsException e)
		{ 
            System.out.println ("Array Index is Out Of Bounds"); 
        }

	}

}
