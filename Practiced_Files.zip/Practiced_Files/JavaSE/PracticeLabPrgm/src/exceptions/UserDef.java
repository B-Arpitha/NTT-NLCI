package exceptions;
class MyException extends Exception 
{ 
   public String getMessage() 
  {
	  return("Exception is user defined");
  }
} 
  
public class UserDef 
{ 
    
    public static void main(String args[]) 
    { 
        try
        { 
        	throw new MyException();  // Throw an object of user defined exception 
        } 
        catch (MyException ex) 
        { 
            System.out.println("Caught Exception"); 
            System.out.println(ex.getMessage());
        } 
    } 
}


