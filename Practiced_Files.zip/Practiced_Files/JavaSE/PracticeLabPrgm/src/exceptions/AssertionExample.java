package exceptions;

import java.util.Scanner;  

class AssertionExample
{  
	public static void main( String args[] )
	{  
  
		Scanner sc = new Scanner( System.in );  
		System.out.print("Enter ur age ");  
    
		int value = sc.nextInt();  
		assert value <= 18 : " Not valid age";  // this is not working 
  
		System.out.println("value is   age: "+value);  
		
	}   
}  
