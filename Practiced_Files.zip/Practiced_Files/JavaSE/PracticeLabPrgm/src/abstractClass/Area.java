package abstractClass;

import java.util.Scanner;

abstract class Shape
{
	float area;
	abstract void input();
	abstract void calc();
	void disp()
	{
		System.out.println("Area : "+area);
	}	
}

class Rectangle extends Shape
{
	Scanner s = new Scanner(System.in);
	float length,breadth;
	void input()
	{
		System.out.println("Rectangle : ");
		System.out.println("Enter length");
		int length = s.nextInt();
		System.out.println("Enter breadth");
		int breadth = s.nextInt();
	}
	void calc()
	{
		area = length * breadth;
	}
}

class Square extends Shape
{
	Scanner s = new Scanner(System.in);
	float side;
	void input()
	{
		System.out.println("Square : ");
		System.out.println("Enter length of side");
		int side = s.nextInt();
		
	}
	void calc()
	{
		area = side * side;
	}
}

class Circle extends Shape
{
	Scanner s = new Scanner(System.in);
	float radius;
	void input()
	{
		System.out.println("Circle : ");
		System.out.println("Enter radius");
		int side = s.nextInt();
		
	}
	void calc()
	{
		area = 3.14f * radius * radius;
	}
}

class Geometry
{
	void permit(Shape ref)
	{
		ref.input();
		ref.calc();
		ref.disp();
	}
}

public class Area {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Rectangle r = new Rectangle();
		Square sq = new Square();
		Circle c = new Circle();
		Geometry g = new Geometry();
		
		g.permit(r);
		System.out.println("------------------------------------------------------");
		g.permit(sq);
		System.out.println("------------------------------------------------------");
		g.permit(c);

	}

}
