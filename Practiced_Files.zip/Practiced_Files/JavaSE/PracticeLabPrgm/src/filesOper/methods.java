package filesOper;


import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.apache.poi.ss.usermodel.Cell;  
import org.apache.poi.ss.usermodel.*;  
import org.apache.poi.ss.usermodel.Sheet;  
import org.apache.poi.ss.usermodel.Workbook;  
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class methods 
{
	static int rowIndex =0;
	static int rowIndexg =0;
	static int rowIndexb =0;
	static int rowIndexn =0;
	static int rowIndexnm =0;
	static Workbook workbook = new XSSFWorkbook();
	static Workbook workbookg = new XSSFWorkbook();
	static Workbook workbookb = new XSSFWorkbook();
	static Workbook workbookn = new XSSFWorkbook();
	static Workbook workbooknm = new XSSFWorkbook();
	static Sheet revcom = workbook.createSheet("RevCom");
	static Sheet revcomg = workbookg.createSheet("RevCom1");
	static Sheet revcomb = workbookb.createSheet("RevCom2");
	static Sheet revcomn = workbookn.createSheet("RevCom3");
	static Sheet revcomnm = workbooknm.createSheet("RevCom4");
	
	static float numCom;
	int gcom;
	int bcom;
	int ncom;
	  
	String[] readcom(String file) throws Exception 
	{
		methods rc=new methods();
		   //object of the class 
		String[] ret = new String[100];
		//reading the value of 2nd row and 2nd column  
		//System.out.println("enter the number of comments");
		Scanner sc=new Scanner(System.in);	
		numCom = 34;
		for(int j=6;j<numCom+6;j++)
		{
		String vOutput=rc.ReadACellData(j, 7,file);  
		ret[j-6] = vOutput;
		//System.out.println(vOutput); 
		}
		return ret;
		}  
		//method defined for reading a cell  
		public String ReadACellData(int vRow, int vColumn,String file)  
		{  
		String value=null;          //variable for storing the cell value  
		Workbook wb=null;           //initialize Workbook null  
		try  
		{  
		//reading data from a file in the form of bytes 
		
		FileInputStream fis=new FileInputStream(file);  
		//constructs an XSSFWorkbook object, by buffering the whole stream into the memory  
		wb=new XSSFWorkbook(fis);  
		}  
		catch(FileNotFoundException e)  
		{  
		e.printStackTrace();  
		}  
		catch(IOException e1)  
		{  
		e1.printStackTrace();  
		}  
		Sheet sheet=wb.getSheetAt(0);   //getting the XSSFSheet object at given index  
		Row row=sheet.getRow(vRow);     //returns the logical row  
		Cell cell=row.getCell(vColumn); //getting the cell representing the given column  
		value=cell.getStringCellValue();    //getting cell value  
		return value;                       //returns the cell value  
		}  
		
		void compkey(String[] com,String file)
		{
			methods rc=new methods();
			
			int i = 4;
			int x = 0;
			
			for(int l = 0; l < numCom ;l++) 
				
			//int l = 0;
			
			{
				String st = "no matching comment";
				String []s = com[l].split(" ");
			for(int j=1;j<=i;j++)
			{
			String vOutput1=rc.ReadACellData(j, 1,file);
			String vOutput2=rc.ReadACellData(j, 2,file);
			String vOutput3=rc.ReadACellData(j, 3,file);
			
			
			     
			  
			    // To temporarily store each individual word  
			    for ( String temp :s) 
			    { 
			        // Comparing the current word 
			        // with the word to be searched 
			    	//System.out.println("temp "+temp +" vOut "+vOutput1 +" , "+vOutput2+" , "+vOutput3);
			    	//System.out.println("vout "+vOutput1+","+vOutput2+","+vOutput3 );
			        if (((temp.compareToIgnoreCase(vOutput1)) == 0 ) || (temp.contains(vOutput1)) == true )
			        { 
			          st = "good comment";
			          gcom++;
			           
			        } 
			        else if (((temp.compareToIgnoreCase(vOutput2)) == 0 ) || (temp.contains(vOutput2)) == true )
			        { 
			        	st = "bad comment";
			        	bcom++;
			            
			        } 
			        else if (((temp.compareToIgnoreCase(vOutput3)) == 0 ) || (temp.contains(vOutput3)) == true ) 
			        { 
			        	st = "neutral comment";
			            ncom++;
			        } 
			        		        
			    } 
			      
	   
			}
			   
			//System.out.println(com[l]+" : "+st);
			writeCommentListToExcel(com[l],st,"final.xlsx");
			}
			
			
		}
		
		
		
		public static void writeCommentListToExcel(String com,String st,String FILE_PATH){
			//String FILE_PATH = "final.xlsx";
	        // Using XSSF for xlsx format, for xls use HSSF
 
	        pojo p = new pojo(com, st);

	            	Row row = revcom.createRow(rowIndex++);
		            int cellIndex = 0;
	            row.createCell(cellIndex++).setCellValue(p.getComment());
	            //second place in row is marks in review
	            row.createCell(cellIndex++).setCellValue(p.getReview());
	        //write this workbook in excel file.
	        try {
	            FileOutputStream fos = new FileOutputStream(FILE_PATH);
	            workbook.write(fos);
	           // fos.close();
	 
	          //  System.out.println(FILE_PATH + " is successfully written");
	        } catch (FileNotFoundException e) {
	            e.printStackTrace();
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
}

		
}
