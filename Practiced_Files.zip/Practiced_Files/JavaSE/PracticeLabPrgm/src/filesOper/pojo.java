package filesOper;

public class pojo {
	private String comment;
	private String review;
	
	public pojo() {
		super();
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	public String getReview() {
		return review;
	}
	public void setReview(String review) {
		this.review = review;
	}
	@Override
	public String toString() {
		return "comment= " + comment + ", review= " + review ;
	}
	public pojo(String comment, String review) {
		super();
		this.comment = comment;
		this.review = review;
	}
	
	

}
