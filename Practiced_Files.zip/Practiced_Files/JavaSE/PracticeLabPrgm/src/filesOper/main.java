package filesOper;

import java.util.Scanner;



public class main {

	public static void main(String[] args) throws Exception 
	{
		methods j = new methods();
		
		
		
		String[] com = j.readcom("a.xlsx");//reading comments and storing it in com var
		
		//System.out.println(com[11]);
		j.compkey(com,"keywords.xlsx");
		System.out.println("num of good comments : " +j.gcom );
		System.out.println("num of bad comments : " +j.bcom);
		System.out.println("num of neutral comments : " +j.ncom);
		System.out.println("num of no matching comments : " +(j.numCom-j.gcom-j.ncom-j.bcom));
		
		

     }

	
}
