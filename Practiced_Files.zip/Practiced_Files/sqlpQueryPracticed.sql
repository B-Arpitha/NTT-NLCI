create database db2;
use db2;
/* creation of table */
create table department (dept_id int primary key, dept_name varchar(20),
loc varchar(10));
insert into department values('1','cs','blore');
insert into department values('2','ece','blore');
insert into department values('3','civ','blore');
insert into department values('4','mech','blore');
create table student (usn integer Primary key, st_name varchar(10) ,
st_marks int, dept_id int, foreign key (dept_id)
 references department(dept_id) );
 /* inserstion into table */
insert into student values ('101','anu','34','1');
insert into student values ('102','sanu','65','2');
insert into student values ('103','anil','90','1');
insert into student values ('104','anusha','85','3');
/* creation of table from another table */
CREATE TABLE TestTable AS
SELECT name, usn
FROM student;
/* alteration of table adding new column */
ALTER TABLE testtable
ADD class int;
/* alteration of table to drop column */
ALTER TABLE testtable
DROP COLUMN class;
/* alteration of table to modify column */
ALTER TABLE testable
MODIFY COLUMN usn varchar(10);
/* constraints */
CREATE TABLE emp (
    first_name varchar(10) not null unique ,
    last_name varchar(10),
    id int primary key ,
    age int check(age>18) 
);
CREATE TABLE emp1 (
    first_name varchar(10) ,
    last_name varchar(10),
    id int primary key ,
    age int 
);
insert into emp1 values ('ram','s','1','30');
insert into emp1 values ('harry','potter','2','24');
insert into emp1 values ('willam','robert','3','36');

/* Dropping Table*/
DROP TABLE Shippers;

/* update */
UPDATE emp
SET first_name = 'Alfredt'
WHERE ID = 1;

/* selection and projection*/
select 'bird' from dual;
select * from emp;
select * from student where usn = 101;

/* pipe operator*/
select first_name ||' '|| last_name 
from emp1;

/* where clause */
select *
from student
where dept_id = 2;

select * from student where st_marks>50;

/*distinct keyword*/
select distinct dept_id
from student;

/* like operator */
select first_name ,last_name
from emp
where last_name like '%s%'or first_name like 'h%';

/* between and not in between  */
select * from student where st_marks between 35 and 80;
select * from student where st_marks not between 35 and 80;

/*In */
select * from student where st_marks in(35,90);

/* Not In*/
 select * from student where st_marks not in(35,90);

/*IS  Null and Is not Null*/
select * from student where marks is not null;
select * from student where marks is null;

/*case manipuplation*/
select Upper(first_name),lower(first_name)from emp1;

/*Charcter  manipuplation*/
select concat(first_name,last_name) from emp1;
select concat(first_name,concat(' ',last_name)) from emp1;

select length(first_name) from emp1;

select substr('RajaRamMohanRoy',9,3) from dual;
select instr(first_name,'a') from emp1;

select trim('m' from 'madam') from dual;
select trim('  madam    ') from dual;

select replace('bangalore','b','m') from dual;
select replace('mississippi','is','15')from dual;

select reverse(first_name) from emp1;

/*number func*/
select round(46549.2585,2) from dual;
select round(46546.2585,-2) from dual;

select truncate(46549.2585,2) from dual;
select truncate(46549.2585,-2) from dual;

select mod(120,2) from dual;

select power(120,2) from dual;

select sqrt(121,2) from dual;

/* Multi-Row Func*/
select max(st_marks) from student;
select min(st_marks) from student;
select sum(st_marks) from student;
select avg(st_marks) from student;
select count(*) from student;

/*order by*/
SELECT * FROM emp1 ORDER BY last_name;

/* nested query*/
select *
 from student
 where dept_id = (select dept_id from department where dept_name = 'cs');
 
/* group by*/
SELECT COUNT(*), first_name
FROM emp1
GROUP BY first_name
ORDER BY first_name DESC;

/*having*/
SELECT COUNT(*), first_name
FROM emp1
GROUP BY first_name
HAVING COUNT(*) > 2
ORDER BY first_name DESC;

/*joins*/
SELECT *
FROM student s
INNER JOIN department d
ON s.dept_id = d.dept_id;

SELECT *
FROM student s
left JOIN department d
ON s.dept_id = d.dept_id;

SELECT *
FROM student s
right JOIN department d
ON s.dept_id = d.dept_id;

SELECT *
FROM student s
full outer JOIN department d /* Syntax Error*/
ON s.dept_id = d.dept_id;











