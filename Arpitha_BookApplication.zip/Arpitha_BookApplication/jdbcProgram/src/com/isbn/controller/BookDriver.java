package com.isbn.controller;

import java.util.Scanner;

import com.isbn.dao.BookOperations;
import com.isbn.domain.Book;

public class BookDriver {

	public static void main(String[] args) 
	{
		Book bp = new Book();
		BookOperations bo = new BookOperations();
		int loop = 0;
		
		while(loop == 0)
		{
			System.out.println("select the option");
			System.out.println("1 -> Insert Book");     			 // Insert and create are same
			System.out.println("2 -> Read Book details");
			System.out.println("3 -> Update Edition of Book");
			System.out.println("4 -> Delete Book");
			Scanner sc = new Scanner(System.in);
			int option = 0;
			try 
			{	
				String opt = sc.next();
				option = Integer.parseInt(opt);
			}
			catch(Exception e)
			{
				System.out.println("exception occured :"+e);
			}
			
			
			switch(option)
			{
				case 1 :
					sc.nextLine(); 
					System.out.println("Enter Book_Name");
					bp.setBookName(sc.nextLine());
					System.out.println("Enter Author_Name");
					bp.setAuthorName(sc.nextLine());
					System.out.println("Enter Edition Number");
					bp.setEdition(sc.nextInt());
					
					int ins = bo.insertBook(bp); //calling  insertBook
					if(ins==1)
						System.out.println("Book Sucessfully Inserted");
					else 
						System.out.println("Book is not Inserted");
					 System.out.println("-----------------------------------------------------------");			
					break;					
				
				
				case 2 :
				
					System.out.println("Enter Isbn_Number");
			        bp.setIsbnNumber(sc.nextInt());
			        System.out.println("-----------------------------------------------------------");
			        Book b1 = bo.readBook(bp);    //calling readBook
			        if(b1!= null)
			        	System.out.println(b1);
			        System.out.println("-----------------------------------------------------------");
					break;
				
				case 3 :
					System.out.println("Enter Isbn_Number");
					bp.setIsbnNumber(sc.nextInt());
					System.out.println("Enter new Edition number to Update");
					bp.setEdition(sc.nextInt());
					int up = bo.updateBook(bp); //calling updateBook
					if(up == 1)
						System.out.println("Edition number Sucessfully Updated");
					else 
						System.out.println("Not Updated.... ");
					 System.out.println("-----------------------------------------------------------");
					 break;
					 
				case 4 :
					System.out.println("Enter Isbn_Number");
					bp.setIsbnNumber(sc.nextInt());
					
					int del = bo.deleteBook(bp); // calling deleteBook
					if(del == 1)
						System.out.println("Book with given Isbn_Number Sucessfully Deleted");
					else 
						System.out.println("Not Deleted..... ");
					 System.out.println("-----------------------------------------------------------");
					 break;
				
				 default:
					    String ex = "Enter Valid Option";
						System.out.println(ex);
					    break;
				 

			}	
			
			System.out.println("Press 0 to continue");
			loop = sc.nextInt();
		}
	}

}
