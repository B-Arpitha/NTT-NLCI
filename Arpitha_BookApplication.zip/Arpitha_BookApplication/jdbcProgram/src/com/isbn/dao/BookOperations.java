package com.isbn.dao;

import java.sql.Connection;

import com.isbn.domain.Book;

public class BookOperations 
{
	Connection con;
	int ret;
	
	public int insertBook(Book b)     //inserts a new book details 
	{
		con = JdbcCon.createCon();
		ret = BookInnerOperations.insertBook(b, con);
		int y = BookInnerOperations.getIsbn(b, con);
		if(y != 0)
			System.out.println("Isbn Number generated for new insertion is : "+y);
		con = JdbcCon.closeCon(con);
		return ret;
	}
		
	public  Book readBook(Book b)    //reads the particular book details using isbn
	{
		con = JdbcCon.createCon();
		Book b1 = null;
		if(BookInnerOperations.validateIsbn(b, con))
			b1 = BookInnerOperations.readBook(b, con);		   
		else
			System.out.println("Invalid Isbn_Number!!!.....");
		con = JdbcCon.closeCon(con);
		return b1 ;
	}
		
	public int updateBook(Book b)  //updates new edition number using isbn
	{
		con = JdbcCon.createCon();
		
		if(BookInnerOperations.validateIsbn(b, con))
			ret = BookInnerOperations.updateBook(b, con);
		else
			System.out.println("Invalid Isbn_Number!!!.....");
		con = JdbcCon.closeCon(con);
		return ret ;
	}
	
	public int deleteBook(Book b)   //deletes book details using isbn
	{
		con = JdbcCon.createCon();
		if(BookInnerOperations.validateIsbn(b,con))
			 ret = BookInnerOperations.deleteBook(b, con);
		else
			System.out.println("Invalid Isbn_Number!!!.....");
		con = JdbcCon.closeCon(con);
		return ret ;
	}	
}