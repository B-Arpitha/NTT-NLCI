package com.isbn.dao;

public class SqlMapper 
{
	public static String addBook =	"insert into book(Book_Name, Author_Name, Edition) values (?,?,?)";
	public static String getIsbn =	"select * from book where Book_Name = ? and Author_name =? and Edition =?";
	public static String fetchBook = "select * from book where isbn_number = ?";
	public static String updateBook = "update book set edition = ? where isbn_number = ?";
	public static String deleteBook = "delete from book where isbn_number = ?";
}
