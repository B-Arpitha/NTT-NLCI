package com.isbn.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.isbn.domain.Book;

public class BookInnerOperations 
{
	static PreparedStatement pt;
	static ResultSet rs;
	
	public static int insertBook(Book b, Connection con)     //inserts a new book details
	{
		int ret = 0;
		try 
		{
			if(con!=null)
			{
				pt = con.prepareStatement(SqlMapper.addBook);
				pt.setString(1 , b.getBookName());
				pt.setString(2 , b.getAuthorName());
				pt.setInt(3 , b.getEdition());
				ret = pt.executeUpdate();
			}
		} 
		catch (SQLException e) 
		{
			System.out.println(e);
		}	
		finally
		{
			try 
			{
				if(pt!=null)
					pt.close();
			} 
			catch (SQLException e) 
			{
				System.out.println(e);
			}
		}
		return ret;
	}
	
	public static int getIsbn(Book b, Connection con)     //gets Isbn of inserted 
	{
		int ret = 0;
		try 
		{
			if(con!=null)
			{
				pt = con.prepareStatement(SqlMapper.getIsbn);
				pt.setString(1 , b.getBookName());
				pt.setString(2 , b.getAuthorName());
				pt.setInt(3 , b.getEdition());
				if(pt!=null)
				{
					rs = pt.executeQuery();
					while(rs.next()) 
					{
						ret = rs.getInt("Isbn_Number");
					}
				}
			}
		} 
		catch (SQLException e) 
		{
			System.out.println(e);
		}	
		finally
		{
			try 
			{
				if(rs != null)
					 rs.close();
				if(pt != null)
					 pt.close();
			} 
			catch (SQLException e) 
			{
				System.out.println(e);
			}
		}
		return ret;
	}
	
	public static boolean validateIsbn(Book b,Connection con)  //checks whether particular isbn is present in table
	{
		boolean bool = false;
		try 
		{
			if(con!= null)
			{
				pt = con.prepareStatement(SqlMapper.fetchBook);
				if(pt!= null)
				{
					pt.setInt(1 , b.getIsbnNumber());
					rs = pt.executeQuery();
					bool = rs.next();
				}
			}
		} 
		catch (SQLException e) 
		{
			System.out.println(e);
		}
		finally
		{
			try 
			{
				if(rs != null)
				 rs.close();
				if(pt != null)
				 pt.close();
			} 
			catch (SQLException e) 
			{
				System.out.println(e);
			}
		}
		return (bool);
	}
	
	public static Book readBook(Book b ,Connection con)  //reads the particular book details using isbn
	{	
		try 
		{
			if(con!=null)
			{
				pt = con.prepareStatement(SqlMapper.fetchBook);
				pt.setInt(1 , b.getIsbnNumber());
				if(pt!=null)
				{
					rs = pt.executeQuery();
					while(rs.next()) 
					{
						b.setAuthorName(rs.getString("Author_Name"));
						b.setBookName(rs.getString("Book_Name"));
						b.setEdition(rs.getInt("Edition"));
						b.setIsbnNumber(rs.getInt("Isbn_Number"));
					}	
				}
			}
		} 
		catch (SQLException e) 
		{
			System.out.println(e);
		}
		finally
		{
			try 
			{
				if(rs != null)
					rs.close();
				if(pt != null)
					pt.close();
			} 
			catch (SQLException e) 
			{
				System.out.println(e);
			}
		}
		return b;
	}
	
	public static int updateBook(Book b, Connection con)  //updates new edition number using isbn
	{
		int ret = 0;
		try 
		{
			if(con!=null)
			{
				pt = con.prepareStatement(SqlMapper.updateBook);
				pt.setInt(1, b.getEdition());
				pt.setInt(2,b.getIsbnNumber());
				ret = pt.executeUpdate();
			}
		} 
		catch (SQLException e) 
		{
			System.out.println(e);
		}
		finally
		{
			try 
			{
				if(pt!=null)
					pt.close();
			} 
			catch (SQLException e) 
			{
				System.out.println(e);
			}
		}
		return ret;
	}
	
	public static int deleteBook(Book bp, Connection con)  //delete book details using isbn
	{
		int ret = 0;
		try
		{
			if(con!=null)
			{
				PreparedStatement pt = con.prepareStatement(SqlMapper.deleteBook);
				pt.setInt(1,bp.getIsbnNumber());
				ret = pt.executeUpdate();
			}
		}
		catch (SQLException e) 
		{
			System.out.println(e);
		}
		finally
		{
			try 
			{
				if(pt!=null)
					pt.close();
			} 
			catch (SQLException e) 
			{
				System.out.println(e);
			}
		}
		return ret;	
	}
}
