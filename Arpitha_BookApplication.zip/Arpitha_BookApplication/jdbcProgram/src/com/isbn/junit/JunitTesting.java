package com.isbn.junit;

import static org.junit.jupiter.api.Assertions.*;

import java.sql.Connection;

import org.junit.jupiter.api.Test;

import com.isbn.controller.BookDriver;
import com.isbn.dao.BookInnerOperations;
import com.isbn.dao.BookOperations;
import com.isbn.dao.JdbcCon;
import com.isbn.domain.Book;

class JunitTesting 
{
	BookOperations bo = new BookOperations();
	BookInnerOperations bio = new BookInnerOperations();
	JdbcCon jdbc = new JdbcCon();
	BookDriver bd = new BookDriver();
	
	@Test
	void testInsertTrue1()
	{
		Book bp = new Book("The Rule Breakers","Preeti Shenoy",5);   
		assertEquals(1,bo.insertBook(bp));	// This is properly executed returns success					
	}

	@Test
	void testInsertFailure()// This failure occurs because of null value for author_Name
	{
		Book bp1 = new Book("Revolution 2020",null,5);  
		Book bp2 = new Book(null,"Chetan Bhagat",5); 
		Book bp3 = new Book("Revolution 2020",null,0); 
		assertNotEquals(1,bo.insertBook(bp1));
		assertNotEquals(1,bo.insertBook(bp2));
		assertNotEquals(1,bo.insertBook(bp3));
	}
	
	@Test
	void testReadTrue()
	{
		Book bp1 = new Book();
		bp1.setIsbnNumber(1);
		Book bp = bo.readBook(bp1);
		assertEquals(1,bp.getIsbnNumber());
		assertEquals("Dr. A.P.J. Abdul Kalam",bp.getBookName());
		assertEquals("My Journey",bp.getAuthorName());
		assertEquals(2,bp.getEdition());
	}
	
	@Test
	void testReadFalse()
	{
		Book bp1 = new Book();
		bp1.setIsbnNumber(0);
		Book bp = bo.readBook(bp1);
		assertNull(bp);
	}
	
	@Test
	void testUpdateTrue()
	{
		Book bp1 = new Book();
		bp1.setIsbnNumber(1);
		bp1.setEdition(2);
		assertEquals(1,bo.updateBook(bp1));
	}
	
	@Test
	void testUpdateFalse()
	{
		Book bp1 = new Book();
		bp1.setIsbnNumber(1);
		bp1.setEdition(0);
		assertNotEquals(1,bo.updateBook(bp1));
		bp1.setIsbnNumber(0);
		assertNotEquals(1,bo.updateBook(bp1));
	}
	
	@Test
	void testDeleteTrue()
	{
		Book bp = new Book("The Rule Breakers","Preeti Shenoy",5);  
		Connection con = jdbc.createCon();
		int isbn = bio.getIsbn(bp, con);
		Book bp1 = new Book();
		bp1.setIsbnNumber(isbn);
		assertEquals(1, bo.deleteBook(bp1));
		
	}
	
	@Test
	void testDeleteFalse()
	{
		Book bp = new Book("The Rule Breakers","Preeti Shenoy",1);  
		Connection con = jdbc.createCon();
		int isbn = bio.getIsbn(bp, con);
		con = jdbc.closeCon(con);
		Book bp1 = new Book();
		bp1.setIsbnNumber(isbn);
		assertNotEquals(1, bo.deleteBook(bp1));
		bp1.setIsbnNumber(0);
		assertNotEquals(1, bo.deleteBook(bp1));		
	}
	
	@Test
	void testValidateIsbnTrue()
	{
		Book bp = new Book();  
		bp.setIsbnNumber(1);
		Connection con = null;
		assertNotEquals(true, bio.validateIsbn(bp, con));
	}
	
	@Test
	void testValidateIsbnFalse()
	{
		Book bp = new Book();  
		bp.setIsbnNumber(0);
		Connection con = jdbc.createCon();
		assertNotEquals(true, bio.validateIsbn(bp, con));
		con = jdbc.closeCon(con);
	}
	
	@Test
	void testVDriverTrue()
	{
		String[] args = null;
		bd.main(args);
	}
}